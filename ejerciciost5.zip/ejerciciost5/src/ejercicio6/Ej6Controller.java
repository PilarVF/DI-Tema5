package ejercicio6;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Ej6Controller {
	@FXML
	private TextField field_username;

	@FXML
	private PasswordField field_password;

	@FXML
	private Button btnEnviar;

	@FXML
	private void enviarClicked() {
		String username = field_username.getText();
		String password = field_password.getText();

		System.out.println("Username: " + username);
		System.out.println("Password: " + password);
	}
}