package ejercicio8;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Ej8Controller {
	@FXML
	private Button boton1, boton2, boton3, boton4, button;
	
	@FXML
	private void handleButtonClick(ActionEvent event) {
		String idBotonPulsado = ((Button)event.getSource()).getId();
		System.out.println("Botón pulsado: " + idBotonPulsado);
		
		switch(idBotonPulsado) {
		case "Button1":
			System.out.println("¡Has pulsado el botón 1!");
			break;
			
		case "Button2":
			System.out.println("¡Has pulsado el botón 2!");
			break;
			
		case "Button3":
			System.out.println("¡Has pulsado el botón 3!");
			break;
			
		case "Button4":
			System.out.println("¡Has pulsado el botón 4!");
			break;
			
		case "Button":
			System.out.println("¡Has pulsado button!");
			break;
			
		default:
			System.out.println("Botón no reconocido.");
			break;
		}
	}
}