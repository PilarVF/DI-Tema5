module ejerciciost5 {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires javafx.base;
	
	opens ejercicio1 to javafx.graphics, javafx.fxml;
	opens ejercicio2 to javafx.graphics, javafx.fxml;
	opens ejercicio3 to javafx.graphics, javafx.fxml;
	opens ejercicios4y5 to javafx.graphics, javafx.fxml;
	opens ejercicio6 to javafx.graphics, javafx.fxml;
	opens ejercicio7 to javafx.graphics, javafx.fxml;
	opens ejercicio8 to javafx.graphics, javafx.fxml;
	opens ejercicio9 to javafx.graphics, javafx.fxml;
}