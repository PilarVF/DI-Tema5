package ejercicio10;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Ej10Controller {
	@FXML
	private Button botonSalir, botonAceptar, botonCancelar, botonOpcion1, botonOpcion2, botonOpcion3, 
			botonOpcionA, botonOpcionB, botonOpcionC, boton1, boton2, boton3, boton4, boton5, boton6;

	@FXML
	private void handleButtonClick(ActionEvent event) {
		String idBotonPulsado = ((Button) event.getSource()).getId();
		System.out.println("Botón pulsado: " + idBotonPulsado);

		switch (idBotonPulsado) {
		case "BtnSalir":
			System.out.println("¡Has pulsado el botón Salir!");
			break;

		case "BtnAceptar":
			System.out.println("¡Has pulsado el botón Aceptar!");
			break;

		case "BtnCancelar":
			System.out.println("¡Has pulsado el botón Cancelar!");
			break;

		case "BtnOp1":
			System.out.println("¡Has pulsado el botón Opción 1!");
			break;
			
		case "BtnOp2":
			System.out.println("¡Has pulsado el botón Opción 2!");
			break;
			
		case "BtnOp3":
			System.out.println("¡Has pulsado el botón Opción 3!");
			break;
			
		case "BtnOpA":
			System.out.println("¡Has pulsado el botón Opción A!");
			break;
			
		case "BtnOpB":
			System.out.println("¡Has pulsado el botón Opción B!");
			break;
			
		case "BtnOpC":
			System.out.println("¡Has pulsado el botón Opción C!");
			break;

		case "Btn1":
			System.out.println("¡Has pulsado el botón 1!");
			break;

		case "Btn2":
			System.out.println("¡Has pulsado el botón 2!");
			break;

		case "Btn3":
			System.out.println("¡Has pulsado el botón 3!");
			break;

		case "Btn4":
			System.out.println("¡Has pulsado el botón 4!");
			break;
			
		case "Btn5":
			System.out.println("¡Has pulsado el botón 5!");
			break;
			
		case "Btn6":
			System.out.println("¡Has pulsado el botón 6!");
			break;

		case "Button9":
			System.out.println("¡Has pulsado el botón 9!");
			break;

		default:
			System.out.println("Botón no reconocido.");
			break;
		}
	}
}