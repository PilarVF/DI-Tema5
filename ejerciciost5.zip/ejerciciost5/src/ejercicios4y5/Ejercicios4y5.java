package ejercicios4y5;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Ejercicios4y5 extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception {
		Parent root = FXMLLoader.load(getClass().getResource("Ej4y5.fxml"));
		
		primaryStage.setTitle("Ejercicio Botones");
		primaryStage.setScene(new Scene(root, 150, 100));
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}